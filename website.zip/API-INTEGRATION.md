# دليل ربط الموقع مع Control Panel API

## ✅ تم تعديل الموقع بالكامل!

الموقع الآن مربوط بالكامل مع **Control Panel Backend API** ويسحب جميع البيانات ديناميكياً.

---

## 📋 الأقسام المربوطة مع API

### 1️⃣ أسعار الدواجن (Poultry)
- **القسم:** `#poultry`
- **API Endpoint:** `GET /api/items/section/poultry`
- **البيانات:** فراخ بيضاء، ساسو، أمهات، بلدي، رومي (أبيض وأسود)
- **الحقول:** `advertisedPrice`, `executionPrice`, `unit`

### 2️⃣ أسعار الكتاكيت (Chicks)
- **القسم:** `#chicks`
- **API Endpoint:** `GET /api/items/section/chicks`
- **البيانات:** كتكوت ساسو، كتكوت أبيض، شركات مختلفة
- **الحقول:** `price`, `unit`

### 3️⃣ بورصة البيض (Eggs)
- **القسم:** `#eggs`
- **API Endpoint:** `GET /api/items/section/eggs`
- **البيانات:** بيض أبيض، أحمر، بلدي
- **الحقول:** `price` (لكل 30 بيضة)
- **ميزة إضافية:** تلوين تلقائي للبطاقات حسب نوع البيض

### 4️⃣ الخامات الزراعية (Raw Materials)
- **القسم:** `#rawMaterials`
- **API Endpoint:** `GET /api/items/section/rawMaterials`
- **البيانات:** ذرة صفراء، ذرة بيضاء، كسب الصويا، نخالة، مركزات، شعير
- **الحقول:** `price` (بالطن مع فاصل آلاف بالعربي)

### 5️⃣ شركات الأعلاف (Feed Companies)
- **القسم:** `.companies-grid`
- **API Endpoint:** `GET /api/companies`
- **البيانات:** اسم الشركة، الوصف، الأيقونة، اللون، المنتجات
- **الحقول:** `nameAr`, `description`, `icon`, `color`, `products[]`
- **الوظيفة:** عند الضغط على شركة، يعرض منتجاتها من API

---

## 🔄 التحديث التلقائي

```javascript
// البيانات تتحدث تلقائياً كل 5 دقائق
setInterval(loadAllData, 5 * 60 * 1000);
```

---

## 🚀 كيفية الاستخدام

### 1. تشغيل Backend API
```bash
cd c:\Users\007\control-panel\backend
npm install
node src/seed.js    # تحميل البيانات الأولية
npm start           # تشغيل API على http://localhost:5000
```

### 2. فتح الموقع
```
افتح: c:\Users\007\website\index.html
```

### 3. الموقع سيعمل بطريقتين:

#### ✅ مع API (عند تشغيل Backend):
- يسحب جميع الأسعار من قاعدة البيانات
- التحديثات الفورية من Control Panel تظهر مباشرة
- تحديث تلقائي كل 5 دقائق

#### ⚠️ بدون API (عند عدم تشغيل Backend):
- يستخدم البيانات الثابتة في HTML
- رسالة تحذير في Console: "Backend API غير متصل"
- الموقع يعمل بشكل طبيعي مع البيانات الافتراضية

---

## 📡 تغيير عنوان API

إذا كان Backend على سيرفر آخر:

```javascript
// في script.js السطر الأول
const API_URL = 'http://your-server.com:5000/api';
```

أو حفظ في localStorage:
```javascript
localStorage.setItem('apiUrl', 'http://your-server.com:5000/api');
```

---

## 🎨 الوظائف الجديدة المضافة

### `loadPoultryPrices()`
تحميل أسعار الدواجن من API وعرضها في الجدول

### `loadChicksPrices()`
تحميل أسعار الكتاكيت من API وعرضها في الجدول

### `loadEggsPrices()`
تحميل أسعار البيض من API مع تلوين ذكي للبطاقات

### `loadRawMaterialsPrices()`
تحميل أسعار الخامات الزراعية مع تنسيق الأرقام بالعربي

### `loadFeedCompanies()`
تحميل شركات الأعلاف من API وعرضها في Grid

### `showCompanyFeeds(companyName)`
عرض منتجات الشركة من API عند الضغط عليها

### `loadAllData()`
تحميل جميع البيانات دفعة واحدة بشكل متوازي

---

## 🔧 تعديل الأسعار من Control Panel

1. افتح Control Panel: `c:\Users\007\control-panel\admin-panel\index.html`
2. اذهب إلى **Items** (إدارة العناصر)
3. عدّل أي سعر واضغط **حفظ**
4. **الموقع سيتحدث تلقائياً!** (خلال 5 دقائق أو عند إعادة تحميل الصفحة)

---

## 🎯 اختبار التكامل

### طريقة الاختبار:
1. شغّل Backend API
2. افتح Control Panel
3. غيّر سعر **فراخ بيضاء** مثلاً من 60 إلى 65
4. افتح الموقع في المتصفح
5. **النتيجة:** السعر الجديد (65) سيظهر مباشرة!

---

## 📊 مثال على Response من API

### GET /api/items/section/poultry
```json
{
  "success": true,
  "data": [
    {
      "_id": "...",
      "sectionId": "poultry",
      "nameAr": "فراخ بيضاء",
      "icon": "🐔",
      "advertisedPrice": 60,
      "executionPrice": 58,
      "unit": "جنيه/كيلو",
      "order": 1,
      "isActive": true
    },
    // ... المزيد
  ]
}
```

---

## ✅ الملفات المعدلة

- ✅ `c:\Users\007\website\script.js` - إضافة جميع وظائف API
- ✅ `c:\Users\007\website\index.html` - لم يتطلب تعديل (متوافق تماماً)

---

## 🎉 النتيجة النهائية

الآن لديك:
- ✅ **Control Panel** - لإدارة كل شيء
- ✅ **Backend API** - لتخزين ومعالجة البيانات
- ✅ **Website** - يسحب البيانات من API ديناميكياً
- ✅ **Flutter App** - (الخطوة التالية: ربطه مع API)

---

## 📞 الدعم

إذا واجهت أي مشكلة:
1. تأكد من تشغيل Backend API
2. افتح Console في المتصفح (F12)
3. تحقق من رسائل الـ Console للأخطاء
4. راجع `QUICK-START.md` في مجلد control-panel

---

**تم بحمد الله! 🎊**

الموقع الآن مربوط بالكامل مع Control Panel ويسحب جميع الأسعار ديناميكياً.
